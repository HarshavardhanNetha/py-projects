def per_num(l):
    sum=0
    for j in range(1,i+1):
            if(i%j==0):
                sum+=i
    if(sum==l):
        print('Perfevt Number')

