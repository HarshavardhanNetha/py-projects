a=[1,2,3,4,5,7,8]
b=[]
for i in a:
    b=[i]+b
print(b)
