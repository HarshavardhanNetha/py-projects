a=[1,2,3,4,5]
b=[]
x=-1
for i in a:
    b+=[a[x]]
    x-=1
print(b)
